import { test, expect } from "@playwright/test";
test("mock localStorage avec tâches existantes", async ({ page }) => {
	// Injecter un jeu de données avant que la page ne se charge
	await page.addInitScript(() => {
		const mockedTodos = [
			{ title: "Acheter du pain", completed: false },
			{ title: "Préparer le repas", completed: false },
			{ title: "Lire la documentation Playwright", completed: false },
			{ title: "Manger", completed: false },
		];

		mockedTodos[2].completed = true;
		mockedTodos.splice(0, 1);

		localStorage.setItem("react-todos", JSON.stringify(mockedTodos));
	});
	await page.goto("https://demo.playwright.dev/todomvc");
	await page.pause();
	("");
	// Vérification des tâches visibles dans l’interface
	await expect(page.getByText("Préparer le repas")).toBeVisible();
	await expect(
		page.getByText("Lire la documentation Playwright")
	).toBeVisible();
	await expect(page.getByText("Manger")).toBeVisible();
	await expect(
		page
			.locator("li", { hasText: "Lire la documentation Playwright" })
			.locator("input[type=checkbox]")
	).toBeChecked();
});
