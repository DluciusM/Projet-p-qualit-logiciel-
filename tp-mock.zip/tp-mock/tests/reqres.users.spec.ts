import { test, expect } from "@playwright/test";

test("mock de la liste des utilisateurs", async ({ page }) => {
	await page.route("**/api/users?page=2", (route) =>
		route.fulfill({
			status: 200,
			contentType: "application/json",
			body: JSON.stringify({
				data: [
					{
						id: 1,
						first_name: "Jean",
						last_name: "Dupont",
						email: "jean.dupont@example.com",
					},
					{
						id: 2,
						first_name: "Claire",
						last_name: "Martin",
						email: "claire.martin@example.com",
					},
				],
			}),
		})
	);

	await page.route("**/api/users/3", (route) =>
		route.fulfill({
			status: 200,
			contentType: "application/json",
			body: JSON.stringify({
				data: {
					id: 1,
					first_name: "gaga",
					last_name: "gogo",
					email: "gaga.dupont@example.com",
				},
			}),
		})
	);

	await page.route("**/api/login", (route) =>
		route.fulfill({
			status: 400,
			contentType: "application/json",
			body: JSON.stringify({
				data: "Erreur",
			}),
		})
	);

	await page.goto("https://reqres.in/api-docs/");
	await page.pause();
	await page.unroute("**/api/users?page=2");
	await page.unroute("**/api/users/3");
	await page.unroute("**/api/login");


});
